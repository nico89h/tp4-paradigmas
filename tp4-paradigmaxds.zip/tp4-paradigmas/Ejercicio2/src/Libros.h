/*
 * Libros.h
 *
 *  Created on: 26 sep. 2022
 *      Author: Alumno
 */

#ifndef LIBROS_H_
#define LIBROS_H_
#include <iostream>
#include "Fecha.h"
using namespace std;
enum Categoria{
	cl�sico,
	policial,
	novela
};
class Libros {
private:
	static const float IVA;
protected:
	int codigo;
	string titulo;
	string descripcion;
	string autor;
	Categoria categoria;
	Fecha fecha;
public:
	void listarInfo();
	float calcularCosto();
	//inicio de el constructor por sobrecarga
	Libros(int codigo,string titulo,string descripcion,string autor,short m, short d, short a);
	//inicio de constructor por defecto
	Libros();
	//inicio de construct6or cop�a
	Libros(Libros &h);
	virtual ~Libros();
};

#endif /* LIBROS_H_ */
