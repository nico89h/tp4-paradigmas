/*
 * Libros.cpp
 *
 *  Created on: 26 sep. 2022
 *      Author: Alumno
 */

#include "Libros.h"

Libros::Libros() {
	// TODO Auto-generated constructor stub
	this->autor="";
	this->codigo=0;
	this->descripcion="";
	this->titulo="";
	this->fecha;//constructor por defecto
	this->categoria= policial;
}

const float Libros::IVA=21;
Libros::~Libros() {
	// TODO Auto-generated destructor stub
}
Libros::Libros(int codigo,string titulo,string descripcion,string autor, short m, short d, short a){
	this->codigo=codigo;
	this->autor=autor;
	this->descripcion="";
	this->categoria=categoria;
	this->fecha(d, m, a);//inicio de fecha
}

Libros::Libros(Libros & h){
	this->autor=h.autor;
		this->codigo=h.codigo;
		this->descripcion=h.descripcion;
		this->titulo=h.titulo;
		this->fecha=h.fecha;//constructor por defecto
		this->categoria=h.categoria;
}
